import { useState } from 'react';
import { removeRepeatedLetters } from './lib/removeRepeatedLetters';
import { convertLettersToNumbers } from './lib/letterNumberConverter';
import './App.css';
import './caosfera-animation.css';

function App() {
  const [inputText, setInputText] = useState('');
  const [outputText, setOutputText] = useState('');
  const [numbersOutput, setNumbersOutput] = useState('');
  const [removeVowels, setRemoveVowels] = useState(true);
  const [removeConsonants, setRemoveConsonants] = useState(true);
  const [isProcessed, setIsProcessed] = useState(false);

  const handleProcess = () => {
    if (!inputText.trim()) return;
    
    const result = removeRepeatedLetters(inputText, removeVowels, removeConsonants);
    setOutputText(result);
    
    // Converter para números
    const numbers = convertLettersToNumbers(result);
    setNumbersOutput(numbers);
    
    setIsProcessed(true);
  };

  const handleReset = () => {
    setInputText('');
    setOutputText('');
    setNumbersOutput('');
    setIsProcessed(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-black to-gray-800 p-4 md:p-8">
      <div className="max-w-3xl mx-auto bg-black bg-opacity-70 rounded-xl shadow-lg p-6 md:p-8 border border-gray-700">
        <div className="flex justify-center mb-6">
          <div className="caosfera-container">
            <div className="caosfera-glow"></div>
            <div className="caosfera-background"></div>
            <img src="/images/caosfera.png" alt="Símbolo do Caos" className="caosfera-image" />
          </div>
        </div>
        
        <h1 className="text-3xl font-bold text-center text-purple-400 mb-6">
          Construção de Sigilos do CAOS
        </h1>
        
        <div className="mb-8">
          <p className="text-gray-300 mb-4 text-center">
            Digite a sua frase para a construção de sigilo do CAOS
          </p>
        </div>

        <div className="space-y-6">
          <div>
            <label htmlFor="inputText" className="block text-sm font-medium text-gray-300 mb-1">
              Digite seu texto:
            </label>
            <textarea
              id="inputText"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              className="w-full p-3 border border-gray-600 bg-gray-800 text-white rounded-md focus:ring-2 focus:ring-purple-500 focus:border-purple-500 min-h-[120px]"
              placeholder="Digite aqui o seu texto para a elaboração do sigilo do caos"
            />
          </div>

          <div className="flex flex-wrap gap-6">
            <div className="flex items-center">
              <input
                type="checkbox"
                id="removeVowels"
                checked={removeVowels}
                onChange={(e) => setRemoveVowels(e.target.checked)}
                className="h-5 w-5 text-purple-600 focus:ring-purple-500 border-gray-600 rounded"
              />
              <label htmlFor="removeVowels" className="ml-2 block text-sm text-gray-300">
                Remover vogais repetidas
              </label>
            </div>
            
            <div className="flex items-center">
              <input
                type="checkbox"
                id="removeConsonants"
                checked={removeConsonants}
                onChange={(e) => setRemoveConsonants(e.target.checked)}
                className="h-5 w-5 text-purple-600 focus:ring-purple-500 border-gray-600 rounded"
              />
              <label htmlFor="removeConsonants" className="ml-2 block text-sm text-gray-300">
                Remover consoantes repetidas
              </label>
            </div>
          </div>

          <div className="flex flex-wrap gap-4">
            <button
              onClick={handleProcess}
              className="px-6 py-2 bg-purple-600 text-white font-medium rounded-md hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 transition-colors"
            >
              Processar
            </button>
            
            <button
              onClick={handleReset}
              className="px-6 py-2 bg-purple-600 text-white font-medium rounded-md hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 transition-colors"
            >
              Limpar
            </button>
          </div>

          {isProcessed && (
            <div className="space-y-6">
              <div>
                <h2 className="text-lg font-semibold text-gray-200 mb-2">Resultado:</h2>
                <div className="p-4 bg-gray-800 border border-gray-600 rounded-md">
                  <p className="text-gray-200 break-words">{outputText}</p>
                </div>
              </div>
              
              <div>
                <h2 className="text-lg font-semibold text-gray-200 mb-2">Conversão Numérica:</h2>
                <div className="p-4 bg-gray-800 border border-gray-600 rounded-md">
                  <p className="text-gray-200 break-words">{numbersOutput}</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
      
      <footer className="mt-8 text-center text-gray-500 text-sm">
        &copy; {new Date().getFullYear()} Construção de Sigilos do CAOS
      </footer>
    </div>
  );
}

export default App;
