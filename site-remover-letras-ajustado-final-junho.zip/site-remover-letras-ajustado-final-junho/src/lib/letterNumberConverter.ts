/**
 * Função para converter letras em números conforme a tabela especificada
 * @param text - Texto de entrada (deve estar em maiúsculas)
 * @returns String com números correspondentes às letras
 */
export function convertLettersToNumbers(text: string): string {
  if (!text) return '';
  
  // Garantir que o texto não tenha caracteres especiais ou acentos
  const cleanText = text.replace(/[^A-Z0-9]/g, '');
  
  const letterToNumberMap: Record<string, string> = {
    'A': '1', 'J': '1', 'S': '1',
    'B': '2', 'K': '2', 'T': '2',
    'C': '3', 'L': '3', 'U': '3',
    'D': '4', 'M': '4', 'V': '4',
    'E': '5', 'N': '5', 'W': '5',
    'F': '6', 'O': '6', 'X': '6',
    'G': '7', 'P': '7', 'Y': '7',
    'H': '8', 'Q': '8', 'Z': '8',
    'I': '9', 'R': '9'
  };
  
  const result: string[] = [];
  
  for (let i = 0; i < cleanText.length; i++) {
    const char = cleanText[i];
    // Se for uma letra mapeada, substitui pelo número correspondente
    if (letterToNumberMap[char]) {
      result.push(letterToNumberMap[char]);
    } else if (/[0-9]/.test(char)) {
      // Mantém dígitos numéricos
      result.push(char);
    }
    // Ignora qualquer outro caractere
  }
  
  return result.join('');
}

/**
 * Função para gerar a explicação das substituições letra-número
 * @param text - Texto de entrada (deve estar em maiúsculas)
 * @returns String com explicação das substituições
 */
export function generateSubstitutionExplanation(text: string): string {
  if (!text) return '';
  
  // Garantir que o texto não tenha caracteres especiais ou acentos
  const cleanText = text.replace(/[^A-Z0-9]/g, '');
  
  const letterToNumberMap: Record<string, string> = {
    'A': '1', 'J': '1', 'S': '1',
    'B': '2', 'K': '2', 'T': '2',
    'C': '3', 'L': '3', 'U': '3',
    'D': '4', 'M': '4', 'V': '4',
    'E': '5', 'N': '5', 'W': '5',
    'F': '6', 'O': '6', 'X': '6',
    'G': '7', 'P': '7', 'Y': '7',
    'H': '8', 'Q': '8', 'Z': '8',
    'I': '9', 'R': '9'
  };
  
  const substitutions: string[] = [];
  
  for (let i = 0; i < cleanText.length; i++) {
    const char = cleanText[i];
    if (letterToNumberMap[char]) {
      substitutions.push(`${char}=${letterToNumberMap[char]}`);
    }
  }
  
  // Remove duplicatas para não repetir explicações
  const uniqueSubstitutions = [...new Set(substitutions)];
  return uniqueSubstitutions.join(', ');
}
