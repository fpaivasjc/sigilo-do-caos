/**
 * Função para remover acentos de uma string
 * @param text - Texto de entrada
 * @returns String sem acentos
 */
export function removeAccents(text: string): string {
  return text.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
}

/**
 * Função para remover letras repetidas de uma string
 * @param text - Texto de entrada
 * @param removeVowels - Se deve remover apenas vogais repetidas
 * @param removeConsonants - Se deve remover apenas consoantes repetidas
 * @returns String com letras repetidas removidas conforme os parâmetros
 */
export function removeRepeatedLetters(
  text: string,
  removeVowels: boolean,
  removeConsonants: boolean
): string {
  if (!text) return '';
  
  // Se nenhuma opção estiver selecionada, retorna o texto original
  if (!removeVowels && !removeConsonants) return text;
  
  // Remove acentos do texto
  const textWithoutAccents = removeAccents(text);
  
  // Filtra caracteres especiais, pontos e vírgulas antes do processamento
  // Mantém apenas letras sem acentos e espaços
  const filteredText = textWithoutAccents.replace(/[^a-zA-Z\s]/g, '');
  
  const vowels = 'aeiouAEIOU';
  const result: string[] = [];
  
  // Conjuntos para rastrear letras já vistas
  const seenVowels = new Set<string>();
  const seenConsonants = new Set<string>();
  
  for (let i = 0; i < filteredText.length; i++) {
    const char = filteredText[i];
    const isVowel = vowels.includes(char);
    
    // Ignora caracteres que não são letras (espaços)
    if (!/[a-zA-Z]/.test(char)) {
      result.push(char);
      continue;
    }
    
    if (isVowel) {
      // Processa vogais - remove apenas se a opção de vogais estiver marcada
      if (!removeVowels || !seenVowels.has(char.toLowerCase())) {
        result.push(char);
        // Só adiciona ao conjunto se estiver removendo vogais
        if (removeVowels) {
          seenVowels.add(char.toLowerCase());
        }
      }
    } else {
      // Processa consoantes - remove apenas se a opção de consoantes estiver marcada
      if (!removeConsonants || !seenConsonants.has(char.toLowerCase())) {
        result.push(char);
        // Só adiciona ao conjunto se estiver removendo consoantes
        if (removeConsonants) {
          seenConsonants.add(char.toLowerCase());
        }
      }
    }
  }
  
  // Converte o resultado para letras maiúsculas e remove espaços
  return result.join('').toUpperCase().replace(/\s+/g, '');
}
